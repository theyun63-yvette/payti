/* 小工具兼容层：Chrome 61 基线兜底。仅在缺失能力时启用局部回退。 */
(function(){
'use strict';
// Object.fromEntries 局部回退（业务代码依赖，Chrome 61 无此 API）
if(typeof Object.fromEntries!=='function'){
 Object.fromEntries=function(entries){
  var out={},arr=Array.prototype.slice.call(entries);
  for(var i=0;i<arr.length;i++)out[arr[i][0]]=arr[i][1];
  return out;
 };
}
function onReady(fn){
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',fn);
 else fn();
}
// Flex gap 行为检测（按布局实测，不按语法检测）：不支持时用 margin 模拟间距
function supportsFlexGap(){
 var flex=document.createElement('div');
 flex.style.position='absolute';flex.style.visibility='hidden';
 flex.style.display='flex';flex.style.flexDirection='column';flex.style.rowGap='1px';
 flex.appendChild(document.createElement('div'));
 flex.appendChild(document.createElement('div'));
 document.body.appendChild(flex);
 var supported=flex.scrollHeight===1;
 flex.parentNode.removeChild(flex);
 return supported;
}
function collectGapRules(){
 var list=[];
 function scan(rules){
  for(var i=0;i<rules.length;i++){
   var r=rules[i];
   if(r.type===4&&r.cssRules){scan(r.cssRules);continue;}
   if(r.type!==1||!r.style)continue;
   var g=r.style.gap;
   if(!g)continue;
   list.push({sel:r.selectorText,col:r.style.columnGap||g,row:r.style.rowGap||g});
  }
 }
 for(var i=0;i<document.styleSheets.length;i++){
  try{scan(document.styleSheets[i].cssRules);}catch(_e){}
 }
 return list;
}
function px(v){var n=parseFloat(v);return isNaN(n)?0:n;}
function applyFlexGaps(gapRules){
 var els=document.querySelectorAll('body *');
 for(var i=0;i<els.length;i++){
  var el=els[i],cs=getComputedStyle(el);
  if(cs.display!=='flex'&&cs.display!=='inline-flex')continue;
  var col=0,row=0;
  for(var j=0;j<gapRules.length;j++){
   var g=gapRules[j];
   var m=null;
   try{m=el.matches(g.sel);}catch(_e){m=false;}
   if(m){col=px(g.col)||col;row=px(g.row)||row;}
  }
  var kids=el.children;
  for(var k=1;k<kids.length;k++){
   if(col>0)kids[k].style.marginLeft=col+'px';
   if(row>0)kids[k].style.marginTop=row+'px';
  }
 }
}
onReady(function(){
 if(supportsFlexGap()){document.documentElement.classList.add('supports-flex-gap');return;}
 var gapRules=collectGapRules();
 if(!gapRules.length)return;
 var pending=false;
 function schedule(){
  if(pending)return;
  pending=true;
  requestAnimationFrame(function(){pending=false;applyFlexGaps(gapRules);});
 }
 schedule();
 new MutationObserver(schedule).observe(document.body,{childList:true,subtree:true});
});
})();

/* Keep the page header below native status/navigation controls.
   getWindowInfo uses container-relative logical pixels: do not multiply by DPR. */
(function(){
'use strict';
var requestId=0,resizeTimer;
function number(value){return typeof value==='number'&&isFinite(value)&&value>=0?value:null;}
function applyInfo(info,id){
 if(id!==requestId||!info||typeof info!=='object')return;
 var safe=info.safeArea&&number(info.safeArea.top),menus=info.menuButtons;
 var status=number(info.statusBarHeight),screenTop=number(info.screenTop);
 if(safe===null||typeof safe==='undefined')safe=0;
 if(!info.safeArea&&!menus&&status===null)return;
 var top=safe;
 if(status!==null&&screenTop!==null)top=Math.max(top,status-screenTop,0);
 ['back','me','share'].forEach(function(key){
  var rect=menus&&menus[key],bottom=rect&&number(rect.bottom);
  if(bottom!==null&&typeof bottom!=='undefined')top=Math.max(top,bottom);
 });
 var height=number(info.windowHeight);
 if(height!==null&&top>=height)return;
 document.documentElement.style.setProperty('--payti-top-clearance',(top>0?Math.ceil(top)+12:0)+'px');
}
function refresh(){
 var xhs=window.xhs,mini=xhs&&xhs.miniTool,id=++requestId;
 if(!mini||typeof mini.getWindowInfo!=='function')return;
 function request(options){
  var env=options&&options.miniToolEnv,build=env&&Number(env.buildVersion);
  if(build&&Math.floor(build/1000)<9490)return;
  try{Promise.resolve(mini.getWindowInfo()).then(function(info){applyInfo(info,id);},function(){});}catch(_e){}
 }
 var options=xhs.launchOptions;
 if(options&&options.miniToolEnv&&options.miniToolEnv.buildVersion){request(options);return;}
 if(typeof mini.getLaunchOptions==='function'){
  try{Promise.resolve(mini.getLaunchOptions()).then(request,function(){request(null);});}catch(_e){request(null);}
 }else request(null);
}
function schedule(){clearTimeout(resizeTimer);resizeTimer=setTimeout(refresh,120);}
refresh();
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',refresh);
window.addEventListener('pageshow',refresh);
window.addEventListener('resize',schedule);
window.addEventListener('orientationchange',schedule);
document.addEventListener('visibilitychange',function(){if(!document.hidden)refresh();});
// Allow a delayed host SDK injection; no ongoing polling.
setTimeout(refresh,500);
setTimeout(refresh,1500);
})();
